/**
 * Notes:
 * User: ${USER}
 * DateTime: ${DATE} ${TIME}
*/