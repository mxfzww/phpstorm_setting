/**
 * @var ${TYPE_HINT}
 */